//
//  GUI_internApp.swift
//  GUI_intern
//
//  Created by Fedor Kukso on 17.04.2024.
//

import SwiftUI

@main
struct GUI_internApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
