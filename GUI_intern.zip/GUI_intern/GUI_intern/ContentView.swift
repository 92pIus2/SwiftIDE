import SwiftUI
import Cocoa
import AppKit


struct ContentView: View {
    @State private var code: String = ""
    @State private var output: String = ""
    @State private var dividerWidth: CGFloat = 200.0
    @State private var selectedFolder: URL?
    @State private var fileName: String = "script.kts"
    
    var body: some View {
        GeometryReader { geometry in
            HStack(spacing: 0) {
                VStack(spacing: 0) {
                    Divider()
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(alignment: .trailing, spacing: 0) {
                            ForEach(code.components(separatedBy: .newlines).indices, id: \.self) { index in
                                Text("\(index)")
                                    .padding(.trailing, 5)
                                    .font(.system(size: 12, design: .monospaced))
                            }
                        }
                    }
                    .frame(maxWidth: 40)
                    .background(Color.gray.opacity(0.2))
                    .padding(.top, 30)
                    Divider()
                }
                
                // Vertical Divider
                //Divider()
                  //  .frame(height: geometry.size.height)
                
                VStack {
                    Text(fileName)
                        .font(.headline)
                        .padding(.bottom, 5)
                    SyntaxHighlightedTextView(text: $code)
                                    .border(Color.gray, width: 1)
                                    .frame(width: dividerWidth - 50)

                                   
                }
                
                VStack {
                    Button(action: {
                        runCode()
                    }) {
                        Label("Run", systemImage: "play.circle")
                    }
                    .padding(.top, 20)

                    Button(action: {
                        saveCode()
                    }) {
                        Label("Save", systemImage: "square.and.arrow.down")
                    }
                    .padding(.top, 20)

                    /*Button(action: {
                        addCode()
                    }) {
                        Label("Add", systemImage: "plus")
                    }
                    .padding(.top, 20)*/
                }
                .frame(width: 80, height: geometry.size.height)
                .background(Color.gray.opacity(0.2))
                .gesture(DragGesture()
                            .onChanged { value in
                                let newWidth = dividerWidth + value.translation.width
                                if newWidth > 50 && newWidth < geometry.size.width - 50 {
                                    dividerWidth = newWidth
                                }
                            })
                
                ScrollView {
                    Text(output)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                }
                .frame(width: geometry.size.width - dividerWidth - 50)
                .background(Color.black)
                .border(Color.gray, width: 1)
            }
        }
        .onAppear {
            selectFolderOrFile()
        }
    }
    
    private func selectFolderOrFile() {
        let openPanel = NSOpenPanel()
        openPanel.canChooseDirectories = true
        openPanel.canChooseFiles = true
        openPanel.allowsMultipleSelection = false
        openPanel.begin { (result) in
            if result.rawValue == NSApplication.ModalResponse.OK.rawValue {
                if let url = openPanel.urls.first {
                    if url.hasDirectoryPath {
                        selectedFolder = url
                        enterFileName()
                    } else {
                        do {
                            let fileContent = try String(contentsOf: url)
                            code = fileContent
                            fileName = url.lastPathComponent
                            saveCode()
                        } catch {
                            print("Error reading file: \(error)")
                        }
                    }
                }
            }
        }
    }


    private func enterFileName() {
        let alert = NSAlert()
        alert.messageText = "Enter File Name"
        alert.addButton(withTitle: "Save")
        alert.addButton(withTitle: "Cancel")
        
        let fileNameTextField = NSTextField(frame: NSRect(x: 0, y: 0, width: 200, height: 24))
        fileNameTextField.placeholderString = "File Name"
        
        alert.accessoryView = fileNameTextField
        
        let response = alert.runModal()
        
        if response == .alertFirstButtonReturn {
            fileName = fileNameTextField.stringValue.isEmpty ? "script.kts" : fileNameTextField.stringValue
            saveCode()
        }
    }

    
    private func runCode() {
        saveCode()
        if let dir = selectedFolder {
            let path = dir.appendingPathComponent(fileName)

            let process = Process()
            let pipe = Pipe()
            print("Attempting to run script at path: \(path.path)")

            process.standardOutput = pipe
            process.standardError = pipe
            process.executableURL = URL(fileURLWithPath: "/opt/homebrew/bin/kotlinc")
            process.arguments = ["-script", path.path]
            
            do {
                try process.run()
                process.waitUntilExit()

                let data = pipe.fileHandleForReading.readDataToEndOfFile()
                let output = String(data: data, encoding: .utf8) ?? "Error reading output"
                
                DispatchQueue.main.async {
                    self.output = output
                }
            } catch {
                DispatchQueue.main.async {
                    self.output = "Failed to run script: \(error.localizedDescription)"
                }
            }
        }
    }
    
    private func saveCode() {
        let text = code

        if let dir = selectedFolder {
            let path = dir.appendingPathComponent(fileName)

            do {
                try text.write(to: path, atomically: false, encoding: .utf8)
            } catch {
                output = "Error saving file: \(error)"
            }
        }
    }
    
    private func addCode() {
        let mainBundleURL = Bundle.main.bundleURL
            let configuration = NSWorkspace.OpenConfiguration()
            NSWorkspace.shared.openApplication(at: mainBundleURL, configuration: configuration) { (app, error) in
                if let error = error {
                    print("Error opening application: \(error)")
                }
            }
    }
}


struct SyntaxHighlightedTextView: NSViewRepresentable {
    @Binding var text: String

    func makeNSView(context: Context) -> NSScrollView {
        let scrollView = NSScrollView()
        let textView = NSTextView()
        scrollView.documentView = textView
        scrollView.hasVerticalScroller = true
        textView.isEditable = true
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = true
        textView.autoresizingMask = [.width, .height]
        textView.backgroundColor = NSColor.black
        textView.textColor = NSColor.white
        textView.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        textView.delegate = context.coordinator
        return scrollView
    }

    func updateNSView(_ nsView: NSScrollView, context: Context) {
        guard let textView = nsView.documentView as? NSTextView else { return }
        textView.string = text
        context.coordinator.syntaxHighlight(textView: textView)
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, NSTextViewDelegate {
        var parent: SyntaxHighlightedTextView

        init(_ parent: SyntaxHighlightedTextView) {
            self.parent = parent
        }

        func textDidChange(_ notification: Notification) {
            if let textView = notification.object as? NSTextView {
                parent.text = textView.string
                syntaxHighlight(textView: textView)
            }
        }
        
        func syntaxHighlight(textView: NSTextView) {
            let content = textView.string
            let attributedString = NSMutableAttributedString(string: content, attributes: [.foregroundColor: NSColor.white, .font: NSFont.monospacedSystemFont(ofSize: 12, weight: .regular)])
            let keywords = ["fun", "var", "val", "if", "else", "return", "try", "catch", "class", "break"]
            let colors = [NSColor.green, NSColor.blue, NSColor.blue, NSColor.yellow, NSColor.yellow, NSColor.red, NSColor.orange, NSColor.orange, NSColor.green, NSColor.red]

            let pattern = "\\b(" + keywords.joined(separator: "|") + ")\\b"
            if let regex = try? NSRegularExpression(pattern: pattern) {
                for match in regex.matches(in: content, range: NSRange(content.startIndex..., in: content)) {
                    let keyword = String(content[Range(match.range, in: content)!])
                    if let index = keywords.firstIndex(of: keyword) {
                        attributedString.addAttribute(.foregroundColor, value: colors[index % colors.count], range: match.range)
                    }
                }
            }
            textView.textStorage?.setAttributedString(attributedString)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


